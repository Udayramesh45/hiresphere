import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import PropTypes from 'prop-types';

const ApplyModal = ({ show, handleClose, job, onSubmit }) => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        resume: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit(job.id, formData);
        setFormData({ name: '', email: '', resume: '' }); // Reset form
    };

    if (!job) return null;

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Apply for {job.title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <p className="text-muted">at {job.company}</p>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3" controlId="formName">
                        <Form.Label>Full Name</Form.Label>
                        <Form.Control
                            type="text"
                            placeholder="Enter your name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formEmail">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control
                            type="email"
                            placeholder="Enter email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formResume">
                        <Form.Label>Upload Resume (PDF/DOC)</Form.Label>
                        <Form.Control
                            type="file"
                            accept=".pdf,.doc,.docx"
                            name="resume"
                            onChange={(e) => {
                                setFormData(prev => ({ ...prev, resume: e.target.files[0] ? e.target.files[0].name : '' }))
                            }}
                            required
                        />
                        <Form.Text className="text-muted">
                            Max file size: 5MB. Supported formats: .pdf, .doc, .docx
                        </Form.Text>
                    </Form.Group>

                    <div className="d-flex justify-content-end gap-2">
                        <Button variant="secondary" onClick={handleClose}>
                            Close
                        </Button>
                        <Button variant="primary" type="submit">
                            Submit Application
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

ApplyModal.propTypes = {
    show: PropTypes.bool.isRequired,
    handleClose: PropTypes.func.isRequired,
    job: PropTypes.object,
    onSubmit: PropTypes.func.isRequired
};

export default ApplyModal;
