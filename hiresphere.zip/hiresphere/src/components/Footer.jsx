import React from 'react';
import { Container } from 'react-bootstrap';

const Footer = () => {
    return (
        <footer className="footer mt-auto py-3 bg-light text-center">
            <Container>
                <span className="text-muted">© 2026 HireSphere. Built for the Interview.</span>
            </Container>
        </footer>
    );
};

export default Footer;
