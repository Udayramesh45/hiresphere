import React from 'react';
import { Row, Col } from 'react-bootstrap';
import JobCard from './JobCard';
import PropTypes from 'prop-types';

const JobList = ({ jobs, onApply, appliedJobIds }) => {
    if (!jobs || jobs.length === 0) {
        return <div className="text-center py-5">No jobs found.</div>;
    }

    return (
        <Row xs={1} md={2} lg={3} className="g-4">
            {jobs.map(job => (
                <Col key={job.id}>
                    <JobCard
                        job={job}
                        onApply={onApply}
                        isApplied={appliedJobIds.includes(job.id)}
                    />
                </Col>
            ))}
        </Row>
    );
};

JobList.propTypes = {
    jobs: PropTypes.array.isRequired,
    onApply: PropTypes.func,
    appliedJobIds: PropTypes.array.isRequired
};

export default JobList;
