import React from 'react';
import { Card, Button, Badge } from 'react-bootstrap';
import PropTypes from 'prop-types';

import { useNavigate } from 'react-router-dom';

const JobCard = ({ job, onApply, isApplied }) => {
    const navigate = useNavigate();

    return (
        <Card
            className="h-100 shadow-sm job-card-hover glass-effect"
            onClick={() => navigate(`/job/${job.id}`)}
        >
            <Card.Body>
                <div className="d-flex justify-content-between align-items-start mb-2">
                    <Card.Title>{job.title}</Card.Title>
                    {isApplied && <Badge bg="success">Applied</Badge>}
                </div>
                <Card.Subtitle className="mb-2 text-muted">{job.company}</Card.Subtitle>
                <Card.Text>
                    <small className="text-secondary"><i className="bi bi-geo-alt-fill me-1"></i> {job.location}</small>
                    <br />
                    <small className="text-secondary"><i className="bi bi-currency-dollar me-1"></i> {job.salary}</small>
                </Card.Text>
                <Card.Text className="text-truncate">
                    {job.description}
                </Card.Text>
                <div className="mt-3">
                    <Button
                        variant="outline-primary"
                        size="sm"
                        onClick={(e) => {
                            e.stopPropagation(); // Prevent card click
                            navigate(`/job/${job.id}`);
                        }}
                    >
                        View Details
                    </Button>
                </div>
            </Card.Body>
            <Card.Footer className="text-muted small">
                Posted: {job.postedDate}
            </Card.Footer>
        </Card>
    );
};

JobCard.propTypes = {
    job: PropTypes.object.isRequired,
    onApply: PropTypes.func,
    isApplied: PropTypes.bool
};

export default JobCard;
