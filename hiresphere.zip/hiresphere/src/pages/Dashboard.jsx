import React from 'react';
import { Container, Alert } from 'react-bootstrap';
import JobList from '../components/JobList';
import jobsData from '../data/jobs.json';
import PropTypes from 'prop-types';

const Dashboard = ({ appliedJobIds }) => {
    // Filter jobs that are in the appliedJobIds list
    const appliedJobs = jobsData.filter(job => appliedJobIds.includes(job.id));

    return (
        <Container className="my-5 py-5">
            <h2 className="mb-4">My Dashboard</h2>
            <Alert variant="info">
                You have applied to <strong>{appliedJobs.length}</strong> jobs.
            </Alert>

            {appliedJobs.length > 0 ? (
                <JobList
                    jobs={appliedJobs}
                    appliedJobIds={appliedJobIds}
                // No onApply passed here, so buttons won't show (or we can pass checks)
                />
            ) : (
                <div className="text-muted p-5 bg-light rounded text-center">
                    <h4>No applications yet.</h4>
                    <p>Go to the Home page to start applying!</p>
                </div>
            )}
        </Container>
    );
};

Dashboard.propTypes = {
    appliedJobIds: PropTypes.array.isRequired
};

export default Dashboard;
