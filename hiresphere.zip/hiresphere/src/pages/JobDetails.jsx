import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Card, Button, Badge, Row, Col } from 'react-bootstrap';
import ApplyModal from '../components/ApplyModal';
import jobsData from '../data/jobs.json';
import PropTypes from 'prop-types';

const JobDetails = ({ onApplyJob, appliedJobIds }) => {
    const { id } = useParams();
    const navigate = useNavigate();
    const job = jobsData.find(j => j.id === parseInt(id));
    const [showModal, setShowModal] = useState(false);

    if (!job) {
        return <div className="text-center py-5">Job not found</div>;
    }

    const isApplied = appliedJobIds.includes(job.id);

    const handleApply = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    const handleFormSubmit = (jobId, formData) => {
        onApplyJob(jobId);
        setShowModal(false);
        alert("Application Submitted Successfully!");
    };

    return (
        <Container className="my-5">
            <Button variant="outline-secondary" className="mb-4" onClick={() => navigate(-1)}>
                &larr; Back to Jobs
            </Button>

            <Card className="glass-effect p-4 border-0">
                <Card.Body>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <h1 className="display-5 fw-bold">{job.title}</h1>
                            <h4 className="text-muted">{job.company}</h4>
                        </div>
                        {isApplied ? (
                            <Badge bg="success" className="fs-5">Applied</Badge>
                        ) : (
                            <Button variant="primary" size="lg" onClick={handleApply}>Apply Now</Button>
                        )}
                    </div>

                    <hr />

                    <Row className="my-4">
                        <Col md={4} className="mb-3">
                            <div className="p-3 bg-light rounded h-100">
                                <h5><i className="bi bi-geo-alt-fill text-primary"></i> Location</h5>
                                <p>{job.location}</p>

                                <h5><i className="bi bi-cash-stack text-success"></i> Salary</h5>
                                <p>{job.salary}</p>

                                <h5><i className="bi bi-briefcase-fill text-info"></i> Type</h5>
                                <p>{job.type}</p>

                                <h5><i className="bi bi-clock-history text-muted"></i> Posted</h5>
                                <p>{job.postedDate}</p>
                            </div>
                        </Col>

                        <Col md={8}>
                            <div className="mb-4">
                                <h3>Job Description</h3>
                                <p>{job.description}</p>
                            </div>

                            <div className="mb-4">
                                <h3>What we are looking for</h3>
                                <p>{job.expectations}</p>
                            </div>

                            <div className="mb-4">
                                <h3>Key Skills</h3>
                                <div className="d-flex flex-wrap gap-2">
                                    {job.skills && job.skills.map((skill, index) => (
                                        <Badge key={index} bg="info" className="p-2 fw-normal fs-6 text-dark">{skill}</Badge>
                                    ))}
                                </div>
                            </div>

                            <div className="mb-4">
                                <h3>Selection Process</h3>
                                <ol className="list-group list-group-numbered list-group-flush">
                                    {job.selectionProcess && job.selectionProcess.map((step, index) => (
                                        <li key={index} className="list-group-item bg-transparent">{step}</li>
                                    ))}
                                </ol>
                            </div>
                        </Col>
                    </Row>
                </Card.Body>
            </Card>

            <ApplyModal
                show={showModal}
                handleClose={handleCloseModal}
                job={job}
                onSubmit={handleFormSubmit}
            />
        </Container>
    );
};

JobDetails.propTypes = {
    onApplyJob: PropTypes.func.isRequired,
    appliedJobIds: PropTypes.array.isRequired
};

export default JobDetails;
