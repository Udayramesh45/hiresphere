import React, { useState } from 'react';
import { Container } from 'react-bootstrap';
import JobList from '../components/JobList';
import ApplyModal from '../components/ApplyModal';
import jobsData from '../data/jobs.json';
import PropTypes from 'prop-types';

const Home = ({ appliedJobIds, onApplyJob }) => {
    const [showModal, setShowModal] = useState(false);
    const [selectedJob, setSelectedJob] = useState(null);

    const handleApplyClick = (job) => {
        setSelectedJob(job);
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setSelectedJob(null);
    };

    const handleFormSubmit = (jobId, formData) => {
        console.log(`Application submitted for job ${jobId}`, formData);
        onApplyJob(jobId);
        handleCloseModal();
        alert("Application Submitted Successfully!");
    };

    return (
        <div className="home-page">
            {/* Hero Section */}
            <div className="hero-section text-center">
                <Container>
                    <h1 className="display-4 fw-bold">Find Your Dream Job</h1>
                    <p className="lead">Join thousands of companies hiring right now.</p>
                </Container>
            </div>

            <Container className="my-5">
                <h2 className="mb-4 text-center">Featured Opportunities</h2>
                <JobList
                    jobs={jobsData}
                    onApply={handleApplyClick}
                    appliedJobIds={appliedJobIds}
                />
            </Container>

            <ApplyModal
                show={showModal}
                handleClose={handleCloseModal}
                job={selectedJob}
                onSubmit={handleFormSubmit}
            />
        </div>
    );
};

Home.propTypes = {
    appliedJobIds: PropTypes.array.isRequired,
    onApplyJob: PropTypes.func.isRequired
};

export default Home;
