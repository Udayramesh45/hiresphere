import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import AppNavbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import JobDetails from './pages/JobDetails';

function App() {
  // Initialize state from localStorage if available
  const [appliedJobIds, setAppliedJobIds] = useState(() => {
    const saved = localStorage.getItem('appliedJobIds');
    return saved ? JSON.parse(saved) : [];
  });

  // Save to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('appliedJobIds', JSON.stringify(appliedJobIds));
  }, [appliedJobIds]);

  const handleApplyJob = (jobId) => {
    if (!appliedJobIds.includes(jobId)) {
      setAppliedJobIds([...appliedJobIds, jobId]);
    }
  };

  return (
    <Router>
      <div className="d-flex flex-column min-vh-100">
        <AppNavbar />
        <main className="flex-grow-1">
          <Routes>
            <Route
              path="/"
              element={<Home appliedJobIds={appliedJobIds} onApplyJob={handleApplyJob} />}
            />
            <Route
              path="/dashboard"
              element={<Dashboard appliedJobIds={appliedJobIds} />}
            />
            <Route
              path="/job/:id"
              element={<JobDetails appliedJobIds={appliedJobIds} onApplyJob={handleApplyJob} />}
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
